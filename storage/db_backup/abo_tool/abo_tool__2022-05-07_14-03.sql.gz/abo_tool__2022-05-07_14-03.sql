
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `street` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (1,'Pruntrutring 83','3217','Köniz','2022-05-06 09:13:43','2022-05-06 09:13:43'),(2,'Philipp-Niederberger-Platz 83','2273','Ebikon','2022-05-06 09:13:43','2022-05-06 09:13:43'),(3,'Fuchsallee 4','3072','Bourg-Saint-Pierre','2022-05-06 09:13:43','2022-05-06 09:13:43'),(4,'Oberwilring 92','6124','Walenstadt','2022-05-06 09:13:43','2022-05-06 09:13:43'),(5,'Peter-Kälin-Gasse 22','2353','Neuenburg','2022-05-06 09:13:43','2022-05-06 09:13:43'),(6,'Horgenweg 10b','6217','Wangen an der Aare','2022-05-06 09:13:43','2022-05-06 09:13:43'),(7,'Katharina-Suter-Weg 3b','2970','Laufenburg','2022-05-06 09:13:43','2022-05-06 09:13:43'),(8,'Annemarie-Fischer-Strasse 35a','6122','La Chaux-de-Fonds','2022-05-06 09:13:43','2022-05-06 09:13:43'),(9,'Gian-Pfister-Strasse 9','1457','Langenthal','2022-05-06 09:13:43','2022-05-06 09:13:43'),(10,'Luzia-Kunz-Ring 7a','6124','Chur','2022-05-06 09:13:43','2022-05-06 09:13:43'),(11,'Walenstadtplatz 548','6124','Valangin','2022-05-06 09:13:43','2022-05-06 09:13:43'),(12,'Nicola-Küng-Ring 0c','6124','Freienbach','2022-05-06 09:13:43','2022-05-06 09:13:43'),(13,'Dominic-Kohler-Weg 4a','3038','Ascona','2022-05-06 09:13:43','2022-05-06 09:13:43'),(14,'Gisela-Meister-Gasse 63','8981','Werdenberg','2022-05-06 09:13:43','2022-05-06 09:13:43'),(15,'Montheyallee 03c','6124','Sursee','2022-05-06 09:13:43','2022-05-06 09:13:43'),(16,'Alfred-Siegrist-Strasse 75','3008','Wettingen','2022-05-06 09:13:43','2022-05-06 09:13:43'),(17,'Georg-Schüpbach-Weg 5a','6130','Renens','2022-05-06 09:13:43','2022-05-06 09:13:43'),(18,'Näfplatz 6','6124','Uzwil','2022-05-06 09:13:43','2022-05-06 09:13:43'),(19,'Oltenplatz 11a','5516','Worb','2022-05-06 09:13:43','2022-05-06 09:13:43'),(20,'Schaubgasse 29a','6635','Richterswil','2022-05-06 09:13:43','2022-05-06 09:13:43'),(21,'Chartreusestrasse 7','3626','Hünibach','2022-05-06 09:13:43','2022-05-06 09:13:43'),(22,'Willisauerstrasse 11','6122','Menznau','2022-05-06 09:18:37','2022-05-06 09:18:37');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bundles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` int NOT NULL COMMENT ' / 100',
  `deliveries` int NOT NULL DEFAULT '0',
  `trial` tinyint(1) NOT NULL DEFAULT '0',
  `short_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bundles` WRITE;
/*!40000 ALTER TABLE `bundles` DISABLE KEYS */;
INSERT INTO `bundles` VALUES (1,1,'12er Abo Gross a 44 CHF',NULL,52800,12,0,NULL,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(2,1,'6er Probe Abo Gross a 44 CHF',NULL,26400,12,0,NULL,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(3,2,'12er Abo Klein à 29 CHF',NULL,34800,12,0,NULL,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(4,2,'6er Probe Abo klein à 29 CHF',NULL,17400,12,0,NULL,'2022-05-07 11:24:02','2022-05-07 11:24:02');
/*!40000 ALTER TABLE `bundles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `buys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `buys` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bill_number` int NOT NULL AUTO_INCREMENT,
  `customer_id` bigint unsigned NOT NULL,
  `bundle_id` bigint unsigned NOT NULL,
  `price` int NOT NULL COMMENT ' / 100',
  `delivery_cost` int NOT NULL COMMENT ' / 100',
  `paid` tinyint(1) NOT NULL DEFAULT '0',
  `issued` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `buys_bill_number_index` (`bill_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2011 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `buys` WRITE;
/*!40000 ALTER TABLE `buys` DISABLE KEYS */;
INSERT INTO `buys` VALUES ('3ab845b5-0056-4029-950f-fc867c241068',2003,1,2,34800,6000,0,'2022-03-11 01:50:44','2022-05-06 09:13:44','2022-05-06 09:13:44'),('432d8f4a-c43b-4b16-aefa-2b071104f7a8',2004,2,3,26400,9600,0,'2022-03-16 08:13:11','2022-05-06 09:13:44','2022-05-06 09:13:44'),('52367cba-3b09-44bc-90a4-91aa7a7f849c',2007,1,4,17400,0,1,'2022-04-19 22:54:25','2022-05-06 09:13:44','2022-05-06 09:13:44'),('6471229b-eed3-452c-b1ca-f1b2a83e9981',2008,11,3,26400,0,1,'2022-04-23 19:51:14','2022-05-06 09:13:44','2022-05-06 09:13:44'),('91193399-b56c-4e9c-bd36-06b9b8280219',2000,1,4,17400,9600,0,'2022-02-16 09:47:52','2022-05-06 09:13:44','2022-05-06 09:13:44'),('9d78b1d1-31bb-45a3-9c4c-7084bc00a9c4',2006,10,3,26400,0,1,'2022-03-16 23:53:10','2022-05-06 09:13:44','2022-05-06 09:13:44'),('b87892b9-41ca-4f6f-9094-0ea3c28c2187',2009,9,4,17400,14400,1,'2022-02-13 11:47:43','2022-05-06 09:13:44','2022-05-06 09:13:44'),('c07f8c65-1aaf-4e09-8a39-9f1d85104071',2005,6,3,26400,12000,1,'2022-03-23 22:34:30','2022-05-06 09:13:44','2022-05-06 09:13:44'),('cfd11af1-f082-4d61-9585-55ae0926b15f',2010,13,1,52800,9600,0,'2022-05-06 09:18:37','2022-05-06 09:18:37','2022-05-06 09:18:37'),('f7922718-05eb-4ff6-9dec-077997605103',2002,10,1,52800,14400,0,'2022-03-01 05:43:20','2022-05-06 09:13:44','2022-05-06 09:13:44'),('f952e307-28cc-4a10-990b-1e163e1c761c',2001,3,1,52800,0,0,'2022-02-17 00:09:09','2022-05-06 09:13:44','2022-05-06 09:13:44');
/*!40000 ALTER TABLE `buys` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `delivery_address_id` bigint unsigned DEFAULT NULL,
  `billing_address_id` bigint unsigned DEFAULT NULL,
  `pickup` tinyint(1) NOT NULL DEFAULT '0',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `used_orders` json DEFAULT NULL COMMENT 'verbrauchte orders vor Systemstart',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customers_delivery_address_id_foreign` (`delivery_address_id`),
  KEY `customers_billing_address_id_foreign` (`billing_address_id`),
  CONSTRAINT `customers_billing_address_id_foreign` FOREIGN KEY (`billing_address_id`) REFERENCES `addresses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customers_delivery_address_id_foreign` FOREIGN KEY (`delivery_address_id`) REFERENCES `addresses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,1,8,2,0,'Margrith','Senn',NULL,'0477971783',NULL,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(2,2,NULL,9,0,'Linda','Erni','Kaufmann','+41 88 407 98 77',NULL,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(3,3,19,9,0,'Matthias','Egli',NULL,'+41 46 763 26 37',NULL,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(4,4,3,3,0,'Alina','Egli','Bolliger','+41 (0)65 149 31 24',NULL,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(5,5,NULL,1,0,'Adrian','Imhof',NULL,'0910988922',NULL,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(6,6,15,15,0,'Silvio','Ott',NULL,'0318788029',NULL,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(7,7,1,5,0,'Marina','Kohler','Zwahlen GmbH','075 158 28 00',NULL,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(8,8,20,20,0,'Oliver','Frey',NULL,'0344303852',NULL,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(9,9,NULL,10,0,'Rafael','Frey',NULL,'+41 (0)16 150 25 88',NULL,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(10,10,NULL,19,0,'Angelika','Schwarz',NULL,'+41 91 996 88 44',NULL,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(11,12,15,9,0,'Jürg','Kunde','Imhof Steiner GmbH','+41(0)477291842',NULL,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(12,11,6,9,0,'Elsa','Admin',NULL,'0842554057',NULL,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(13,13,22,22,0,'Samuel','Schwegler',NULL,'+23',NULL,'2022-05-06 09:18:37','2022-05-06 09:18:37');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deliveries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `delivery_service_id` bigint unsigned NOT NULL,
  `date` timestamp NOT NULL,
  `deadline` timestamp NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `deliveries` WRITE;
/*!40000 ALTER TABLE `deliveries` DISABLE KEYS */;
INSERT INTO `deliveries` VALUES (1,1,'2022-04-16 09:13:44','2022-04-14 09:13:44',1,'2022-05-06 09:13:44','2022-04-01 09:13:44'),(2,2,'2022-04-18 09:13:44','2022-04-16 09:13:44',1,'2022-05-06 09:13:44','2022-04-03 09:13:44'),(3,3,'2022-04-19 09:13:44','2022-04-17 09:13:44',1,'2022-05-06 09:13:44','2022-04-04 09:13:44'),(4,1,'2022-04-23 09:13:44','2022-04-21 09:13:44',1,'2022-05-06 09:13:44','2022-04-08 09:13:44'),(5,2,'2022-04-25 09:13:44','2022-04-23 09:13:44',1,'2022-05-06 09:13:44','2022-04-10 09:13:44'),(6,3,'2022-04-26 09:13:44','2022-04-24 09:13:44',1,'2022-05-06 09:13:44','2022-04-11 09:13:44'),(7,1,'2022-04-30 09:13:44','2022-04-28 09:13:44',1,'2022-05-06 09:13:44','2022-04-15 09:13:44'),(8,2,'2022-05-02 09:13:44','2022-04-30 09:13:44',1,'2022-05-06 09:13:44','2022-04-17 09:13:44'),(9,3,'2022-05-03 09:13:44','2022-05-01 09:13:44',1,'2022-05-06 09:13:44','2022-04-18 09:13:44'),(10,1,'2022-05-07 09:13:44','2022-05-05 09:13:44',1,'2022-05-06 09:13:44','2022-04-22 09:13:44'),(11,2,'2022-05-09 09:13:44','2022-05-07 09:13:44',1,'2022-05-06 09:13:44','2022-04-24 09:13:44'),(12,3,'2022-05-10 09:13:44','2022-05-08 09:13:44',1,'2022-05-06 09:13:45','2022-04-25 09:13:44'),(13,1,'2022-05-14 09:13:44','2022-05-12 09:13:44',1,'2022-05-06 09:13:45','2022-04-29 09:13:44'),(14,2,'2022-05-16 09:13:44','2022-05-14 09:13:44',1,'2022-05-06 09:13:45','2022-05-01 09:13:44'),(15,3,'2022-05-17 09:13:44','2022-05-15 09:13:44',1,'2022-05-06 09:13:45','2022-05-02 09:13:44'),(16,1,'2022-05-21 09:13:44','2022-05-19 09:13:44',0,'2022-05-06 09:13:45','2022-05-06 09:13:44'),(17,2,'2022-05-23 09:13:44','2022-05-21 09:13:44',0,'2022-05-06 09:13:45','2022-05-08 09:13:44'),(18,3,'2022-05-24 09:13:44','2022-05-22 09:13:44',0,'2022-05-06 09:13:45','2022-05-09 09:13:44'),(19,1,'2022-05-28 09:13:44','2022-05-26 09:13:44',0,'2022-05-06 09:13:45','2022-05-13 09:13:44'),(20,2,'2022-05-30 09:13:44','2022-05-28 09:13:44',0,'2022-05-06 09:13:45','2022-05-15 09:13:44'),(21,3,'2022-05-31 09:13:44','2022-05-29 09:13:44',0,'2022-05-06 09:13:45','2022-05-16 09:13:44'),(22,1,'2022-06-04 09:13:44','2022-06-02 09:13:44',0,'2022-05-06 09:13:45','2022-05-20 09:13:44'),(23,2,'2022-06-06 09:13:44','2022-06-04 09:13:44',0,'2022-05-06 09:13:45','2022-05-22 09:13:44'),(24,3,'2022-06-07 09:13:44','2022-06-05 09:13:44',0,'2022-05-06 09:13:45','2022-05-23 09:13:44'),(25,1,'2022-06-11 09:13:44','2022-06-09 09:13:44',0,'2022-05-06 09:13:46','2022-05-27 09:13:44'),(26,2,'2022-06-13 09:13:44','2022-06-11 09:13:44',0,'2022-05-06 09:13:46','2022-05-29 09:13:44'),(27,3,'2022-06-14 09:13:44','2022-06-12 09:13:44',0,'2022-05-06 09:13:46','2022-05-30 09:13:44'),(28,1,'2022-06-18 09:13:44','2022-06-16 09:13:44',0,'2022-05-06 09:13:46','2022-06-03 09:13:44'),(29,2,'2022-06-20 09:13:44','2022-06-18 09:13:44',0,'2022-05-06 09:13:46','2022-06-05 09:13:44'),(30,3,'2022-06-21 09:13:44','2022-06-19 09:13:44',0,'2022-05-06 09:13:46','2022-06-06 09:13:44'),(31,1,'2022-06-25 09:13:44','2022-06-23 09:13:44',0,'2022-05-06 09:13:46','2022-06-10 09:13:44'),(32,2,'2022-06-27 09:13:44','2022-06-25 09:13:44',0,'2022-05-06 09:13:46','2022-06-12 09:13:44'),(33,3,'2022-06-28 09:13:44','2022-06-26 09:13:44',0,'2022-05-06 09:13:46','2022-06-13 09:13:44'),(34,1,'2022-07-02 09:13:44','2022-06-30 09:13:44',0,'2022-05-06 09:13:46','2022-06-17 09:13:44'),(35,2,'2022-07-04 09:13:44','2022-07-02 09:13:44',0,'2022-05-06 09:13:46','2022-06-19 09:13:44'),(36,3,'2022-07-05 09:13:44','2022-07-03 09:13:44',0,'2022-05-06 09:13:46','2022-06-20 09:13:44'),(37,1,'2022-07-09 09:13:44','2022-07-07 09:13:44',0,'2022-05-06 09:13:46','2022-06-24 09:13:44'),(38,2,'2022-07-11 09:13:44','2022-07-09 09:13:44',0,'2022-05-06 09:13:46','2022-06-26 09:13:44'),(39,3,'2022-07-12 09:13:44','2022-07-10 09:13:44',0,'2022-05-06 09:13:47','2022-06-27 09:13:44');
/*!40000 ALTER TABLE `deliveries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `delivery_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_item` (
  `delivery_id` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `delivery_item` WRITE;
/*!40000 ALTER TABLE `delivery_item` DISABLE KEYS */;
INSERT INTO `delivery_item` VALUES (1,8),(1,9),(1,10),(1,4),(1,1),(2,7),(2,1),(2,9),(2,6),(2,3),(3,3),(3,9),(3,6),(3,10),(3,5),(4,10),(4,8),(4,9),(4,2),(4,7),(5,5),(5,3),(5,9),(5,1),(5,8),(6,3),(6,4),(6,9),(6,8),(6,1),(7,8),(7,2),(7,9),(7,3),(7,6),(8,4),(8,6),(8,8),(8,3),(8,1),(9,1),(9,4),(9,7),(9,3),(9,5),(10,10),(10,5),(10,3),(10,4),(10,1),(11,6),(11,2),(11,5),(11,1),(11,4),(12,5),(12,6),(12,1),(12,7),(12,8),(13,7),(13,8),(13,3),(13,9),(13,1),(14,6),(14,8),(14,3),(14,5),(14,4),(15,9),(15,1),(15,10),(15,7),(15,5),(16,5),(16,3),(16,10),(16,1),(16,2),(17,7),(17,3),(17,4),(17,6),(17,10),(18,5),(18,3),(18,10),(18,1),(18,8),(19,1),(19,7),(19,5),(19,3),(19,10),(20,3),(20,4),(20,2),(20,10),(20,9),(21,10),(21,7),(21,9),(21,1),(21,8),(22,3),(22,5),(22,10),(22,7),(22,1),(23,6),(23,9),(23,10),(23,7),(23,8),(24,4),(24,8),(24,10),(24,7),(24,5),(25,8),(25,1),(25,10),(25,2),(25,4),(26,2),(26,3),(26,8),(26,7),(26,4),(27,9),(27,8),(27,1),(27,5),(27,2),(28,8),(28,2),(28,6),(28,1),(28,3),(29,8),(29,2),(29,5),(29,7),(29,1),(30,4),(30,3),(30,8),(30,10),(30,9),(31,7),(31,3),(31,9),(31,4),(31,8),(32,9),(32,1),(32,3),(32,5),(32,2),(33,5),(33,8),(33,7),(33,2),(33,3),(34,9),(34,8),(34,4),(34,6),(34,2),(35,4),(35,6),(35,2),(35,1),(35,10),(36,8),(36,3),(36,4),(36,10),(36,1),(37,1),(37,6),(37,7),(37,2),(37,3),(38,2),(38,5),(38,10),(38,4),(38,3),(39,6),(39,2),(39,5),(39,7),(39,1);
/*!40000 ALTER TABLE `delivery_item` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `delivery_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_services` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pickup` tinyint(1) NOT NULL DEFAULT '0',
  `days` json NOT NULL COMMENT 'an welchen Wochentagen soll eine Lieferung ausgelöst werden',
  `deadline_distance` smallint NOT NULL DEFAULT '2' COMMENT 'wie viel Tage vor der Lieferung soll die Deadline enden.',
  `delivery_cost` int NOT NULL DEFAULT '0' COMMENT 'faktor 100',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `delivery_services` WRITE;
/*!40000 ALTER TABLE `delivery_services` DISABLE KEYS */;
INSERT INTO `delivery_services` VALUES (1,'Abholung in Hünibach',1,'[\"sat\"]',2,0,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(2,'Post',0,'[\"mon\"]',2,1200,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(3,'Velokurier',0,'[\"tue\"]',2,800,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(4,'Postcode Adder',0,'[\"fri\"]',2,800,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(5,'Postcode Adder 2',0,'[\"tue\"]',2,500,'2022-05-07 11:24:02','2022-05-07 11:24:02');
/*!40000 ALTER TABLE `delivery_services` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `item_origins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_origins` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `own` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `item_origins` WRITE;
/*!40000 ALTER TABLE `item_origins` DISABLE KEYS */;
INSERT INTO `item_origins` VALUES (1,'Eigenanbau',1,'2022-05-06 09:13:43','2022-05-06 09:13:43'),(2,'Bio (Spanien)',1,'2022-05-06 09:13:44','2022-05-06 09:13:44'),(3,'Bio (Schweiz)',1,'2022-05-06 09:13:44','2022-05-06 09:13:44');
/*!40000 ALTER TABLE `item_origins` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item_origin_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,2,'Stachelbeeren','2022-05-06 09:13:44','2022-05-06 09:13:44'),(2,1,'Rüebli','2022-05-06 09:13:44','2022-05-06 09:13:44'),(3,3,'Apfel Boskop','2022-05-06 09:13:44','2022-05-06 09:13:44'),(4,3,'Tomaten','2022-05-06 09:13:44','2022-05-06 09:13:44'),(5,2,'Batavia Grün','2022-05-06 09:13:44','2022-05-06 09:13:44'),(6,2,'Apfel','2022-05-06 09:13:44','2022-05-06 09:13:44'),(7,3,'Kaffee','2022-05-06 09:13:44','2022-05-06 09:13:44'),(8,3,'Zwiebeln','2022-05-06 09:13:44','2022-05-06 09:13:44'),(9,2,'Zwiebeln','2022-05-06 09:13:44','2022-05-06 09:13:44'),(10,2,'Cherry Tomaten','2022-05-06 09:13:44','2022-05-06 09:13:44');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2019_12_14_000001_create_personal_access_tokens_table',1),(2,'2022_02_16_121143_v0v1v0',1),(3,'2022_02_23_134509_create_permission_tables',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (3,'App\\Models\\User',1),(3,'App\\Models\\User',2),(3,'App\\Models\\User',3),(3,'App\\Models\\User',4),(3,'App\\Models\\User',5),(3,'App\\Models\\User',6),(3,'App\\Models\\User',7),(3,'App\\Models\\User',8),(3,'App\\Models\\User',9),(3,'App\\Models\\User',10),(1,'App\\Models\\User',11),(3,'App\\Models\\User',12),(3,'App\\Models\\User',13);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint unsigned NOT NULL,
  `delivery_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned DEFAULT NULL,
  `canceled` tinyint(1) NOT NULL DEFAULT '0',
  `depository` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Abstellort',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,6,12,2,0,NULL,'2022-05-06 09:13:47','2022-05-06 09:13:47'),(2,6,15,2,0,NULL,'2022-05-06 09:13:47','2022-05-06 09:13:47'),(3,10,13,2,0,NULL,'2022-05-06 09:13:47','2022-05-06 09:13:47'),(4,1,12,1,0,NULL,'2022-05-06 09:13:47','2022-05-06 09:13:47'),(5,1,15,1,0,NULL,'2022-05-06 09:13:47','2022-05-06 09:13:47'),(6,11,12,2,0,NULL,'2022-05-06 09:13:47','2022-05-06 09:13:47'),(7,11,15,2,0,NULL,'2022-05-06 09:13:47','2022-05-06 09:13:47'),(8,9,13,1,0,NULL,'2022-05-06 09:13:47','2022-05-06 09:13:47');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'manage payments','web','2022-05-06 09:13:42','2022-05-06 09:13:42'),(2,'manage delivery services','web','2022-05-06 09:13:42','2022-05-06 09:13:42'),(3,'manage deliveries','web','2022-05-06 09:13:42','2022-05-06 09:13:42'),(4,'manage customers','web','2022-05-06 09:13:42','2022-05-06 09:13:42');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `postcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `postcodes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `postcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_service_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `postcodes_postcode_unique` (`postcode`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `postcodes` WRITE;
/*!40000 ALTER TABLE `postcodes` DISABLE KEYS */;
INSERT INTO `postcodes` VALUES (1,'6122',3,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(2,'6130',3,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(3,'6125',3,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(4,'6124',3,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(5,'3072',2,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(6,'3000',2,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(7,'3008',2,'2022-05-07 11:24:02','2022-05-07 11:24:02');
/*!40000 ALTER TABLE `postcodes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'kleine Gemüsetasche',NULL,'2022-05-07 11:24:02','2022-05-07 11:24:02'),(2,'grosse Gemüsetasche',NULL,'2022-05-07 11:24:02','2022-05-07 11:24:02');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(1,2),(2,2),(3,2),(4,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','web','2022-05-06 09:13:42','2022-05-06 09:13:42'),(2,'office','web','2022-05-06 09:13:42','2022-05-06 09:13:42'),(3,'customer','web','2022-05-06 09:13:42','2022-05-06 09:13:42');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_id` bigint unsigned NOT NULL,
  `besr_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iban` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'Gartenbauschule Huenibach',21,'','CH5330790016597781328','2022-05-06 09:13:43','2022-05-06 09:13:43');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'felix.giger@example.net','2022-05-06 09:13:43','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','tK6MfYZlKl','2022-05-06 09:13:43','2022-05-06 09:13:43'),(2,'dora03@example.org','2022-05-06 09:13:43','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','L9KrItTBZd','2022-05-06 09:13:43','2022-05-06 09:13:43'),(3,'franz.bosshard@example.com','2022-05-06 09:13:43','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','TuOq1KvW6S','2022-05-06 09:13:43','2022-05-06 09:13:43'),(4,'arnold.sebastian@example.org','2022-05-06 09:13:43','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Nvk9eA6EV3','2022-05-06 09:13:43','2022-05-06 09:13:43'),(5,'diego40@example.org','2022-05-06 09:13:43','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','B5mTpCO78u','2022-05-06 09:13:43','2022-05-06 09:13:43'),(6,'livia.fuchs@example.org','2022-05-06 09:13:43','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Yfo2CaB2sp','2022-05-06 09:13:43','2022-05-06 09:13:43'),(7,'zluthi@example.org','2022-05-06 09:13:43','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Y7owviR8cW','2022-05-06 09:13:43','2022-05-06 09:13:43'),(8,'margrit66@example.com','2022-05-06 09:13:43','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','9LRL0pH4t8','2022-05-06 09:13:43','2022-05-06 09:13:43'),(9,'hmeister@example.net','2022-05-06 09:13:43','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','3zKhEEo82L','2022-05-06 09:13:43','2022-05-06 09:13:43'),(10,'olivier.luthi@example.com','2022-05-06 09:13:43','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','U8LEENedfC','2022-05-06 09:13:43','2022-05-06 09:13:43'),(11,'admin@webtheke.ch','2022-05-06 09:13:43','$2y$10$25Nxr0shUTD32WRhyS1c8OxE1Wx1GpJDCQkbRgZUskbF2OPFe8klm','97NpCrOuh8','2022-05-06 09:13:43','2022-05-06 09:13:43'),(12,'kunde@webtheke.ch','2022-05-06 09:13:43','$2y$10$h1E03AhzCnVYppMd2cWTreihiq9PzgijhseUIk1jPlrf4/yryh6/y','9U9JaQsWcn','2022-05-06 09:13:43','2022-05-06 09:13:43'),(13,'samuel.schwegler@gmx.ch',NULL,'$2y$10$XqVB21Wm4lUeOaN1vk4rZOA8cdc.2dgAeXSaNPHw8gReTcphdby/G',NULL,'2022-05-06 09:18:37','2022-05-06 09:18:37');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

